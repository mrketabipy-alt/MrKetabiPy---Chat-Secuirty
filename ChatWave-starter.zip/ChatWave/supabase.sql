-- ChatWave database schema for Supabase
-- Run this whole script in Supabase Dashboard > SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique not null,
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  is_group boolean not null default false,
  title text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (conversation_id,user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 4000),
  created_at timestamptz not null default now()
);

create index if not exists messages_conversation_created_idx
  on public.messages(conversation_id,created_at);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  insert into public.profiles(id,email) values(new.id,new.email)
  on conflict (id) do update set email=excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert or update of email on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.is_conversation_member(cid uuid)
returns boolean language sql stable security definer set search_path=public
as $$
  select exists(select 1 from public.conversation_members
                where conversation_id=cid and user_id=auth.uid());
$$;

create or replace function public.create_or_get_dm(other_user uuid)
returns uuid language plpgsql security definer set search_path=public
as $$
declare new_id uuid; existing_id uuid;
begin
  if auth.uid() is null or other_user=auth.uid() then
    raise exception 'Invalid user';
  end if;
  if not exists(select 1 from public.profiles where id=other_user) then
    raise exception 'User not found';
  end if;
  select c.id into existing_id
  from public.conversations c
  join public.conversation_members a on a.conversation_id=c.id and a.user_id=auth.uid()
  join public.conversation_members b on b.conversation_id=c.id and b.user_id=other_user
  where c.is_group=false
    and (select count(*) from public.conversation_members x where x.conversation_id=c.id)=2
  limit 1;
  if existing_id is not null then return existing_id; end if;
  insert into public.conversations(is_group,created_by) values(false,auth.uid()) returning id into new_id;
  insert into public.conversation_members(conversation_id,user_id)
    values(new_id,auth.uid()),(new_id,other_user);
  return new_id;
end;
$$;

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

create policy "Authenticated users can search profiles" on public.profiles
for select to authenticated using (true);
create policy "Users can update own profile" on public.profiles
for update to authenticated using (id=auth.uid()) with check (id=auth.uid());

create policy "Members can view conversations" on public.conversations
for select to authenticated using (public.is_conversation_member(id));
create policy "Members can view membership" on public.conversation_members
for select to authenticated using (public.is_conversation_member(conversation_id));
create policy "Members can read messages" on public.messages
for select to authenticated using (public.is_conversation_member(conversation_id));
create policy "Members can send messages as themselves" on public.messages
for insert to authenticated with check (
  sender_id=auth.uid() and public.is_conversation_member(conversation_id)
);

grant usage on schema public to authenticated;
grant select, update on public.profiles to authenticated;
grant select on public.conversations to authenticated;
grant select on public.conversation_members to authenticated;
grant select, insert on public.messages to authenticated;
grant execute on function public.create_or_get_dm(uuid) to authenticated;
grant execute on function public.is_conversation_member(uuid) to authenticated;

-- Enable Realtime for live incoming messages and conversation updates.
alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.conversation_members;
