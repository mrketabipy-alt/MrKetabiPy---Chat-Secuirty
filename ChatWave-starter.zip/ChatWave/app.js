import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";

// 1) مقادیر پروژه Supabase را از Project Settings > API اینجا قرار بده.
const SUPABASE_URL = "YOUR_SUPABASE_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
const configured = !SUPABASE_URL.startsWith("YOUR_") && !SUPABASE_ANON_KEY.startsWith("YOUR_");
const supabase = configured ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

const $ = (id) => document.getElementById(id);
let mode = "login", currentUser = null, activeConversation = null, messageChannel = null, listChannel = null;
let conversations = [];

function toast(text){ const el=$("toast"); el.textContent=text; el.classList.add("show"); setTimeout(()=>el.classList.remove("show"),2800); }
function showAuth(){ $("authView").classList.remove("hidden"); $("chatView").classList.add("hidden"); }
function showChat(){ $("authView").classList.add("hidden"); $("chatView").classList.remove("hidden"); }
function setMode(next){ mode=next; $("loginTab").classList.toggle("active",mode==="login"); $("signupTab").classList.toggle("active",mode==="signup"); $("authSubmit").textContent=mode==="login"?"ورود به حساب":"ساخت حساب"; $("authMessage").textContent=""; }
$("loginTab").onclick=()=>setMode("login"); $("signupTab").onclick=()=>setMode("signup");

$("authForm").addEventListener("submit", async e=>{
  e.preventDefault();
  if(!configured){$("authMessage").textContent="ابتدا آدرس و کلید Supabase را در فایل app.js وارد کن.";return;}
  const email=$("email").value.trim(), password=$("password").value;
  $("authSubmit").disabled=true;
  const result= mode==="login" ? await supabase.auth.signInWithPassword({email,password}) : await supabase.auth.signUp({email,password});
  $("authSubmit").disabled=false;
  if(result.error){$("authMessage").textContent=result.error.message;return;}
  if(mode==="signup" && !result.data.session){$("authMessage").textContent="ثبت‌نام انجام شد. ایمیلت را برای تأیید حساب بررسی کن.";return;}
  toast("خوش اومدی به ChatWave");
});
$("logoutBtn").onclick=()=>supabase?.auth.signOut();

async function boot(user){
  currentUser=user; showChat();
  $("myEmail").textContent=user.email; $("myAvatar").textContent=(user.email||"م")[0].toUpperCase();
  await loadConversations();
  if(listChannel) supabase.removeChannel(listChannel);
  listChannel=supabase.channel("my-conversations-"+user.id).on("postgres_changes",{event:"*",schema:"public",table:"conversation_members",filter:`user_id=eq.${user.id}`},loadConversations).subscribe();
}
supabase?.auth.onAuthStateChange((_event,session)=>{ if(session?.user) boot(session.user); else {currentUser=null;showAuth();} });

async function findOrCreateDM(otherId){
  const {data,error}=await supabase.rpc("create_or_get_dm",{other_user:otherId});
  if(error){toast(error.message);return;}
  await loadConversations();
  await openConversation(data);
}
$("searchBtn").onclick=searchUsers;
$("userSearch").addEventListener("keydown",e=>{if(e.key==="Enter")searchUsers();});
async function searchUsers(){
  const q=$("userSearch").value.trim().toLowerCase(); $("searchResults").innerHTML="";
  if(q.length<3){toast("حداقل سه حرف یا بخشی از ایمیل را وارد کن.");return;}
  const {data,error}=await supabase.from("profiles").select("id,email").ilike("email",`%${q}%`).neq("id",currentUser.id).limit(8);
  if(error){toast(error.message);return;}
  if(!data?.length){$("searchResults").textContent="کاربری پیدا نشد.";return;}
  data.forEach(p=>{const b=document.createElement("button");b.className="user-result";b.textContent=p.email;b.onclick=()=>findOrCreateDM(p.id);$("searchResults").appendChild(b);});
}
async function loadConversations(){
  const {data,error}=await supabase.from("conversation_members").select("conversation_id, conversations(id, is_group, title, conversation_members(user_id, profiles(id,email)))").eq("user_id",currentUser.id);
  if(error){console.error(error);return;}
  conversations=(data||[]).map(x=>x.conversations).filter(Boolean);
  const list=$("conversationList"); list.innerHTML="";
  if(!conversations.length){list.innerHTML='<div class="empty-list">هنوز گفت‌وگویی نداری.<br/>ایمیل یک کاربر را جست‌وجو کن.</div>';return;}
  for(const c of conversations){
    const peer=c.conversation_members?.map(m=>m.profiles).find(p=>p?.id!==currentUser.id);
    const title=c.is_group?(c.title||"گروه"):peer?.email||"گفت‌وگوی خصوصی";
    const b=document.createElement("button");b.className="convo-item"+(activeConversation===c.id?" selected":"");
    const av=document.createElement("div");av.className="avatar";av.textContent=title[0]?.toUpperCase()||"؟";
    const txt=document.createElement("div");txt.className="convo-text";
    const name=document.createElement("b");name.textContent=title;
    const sub=document.createElement("span");sub.textContent=c.is_group?"گروه":"گفت‌وگوی خصوصی";
    txt.append(name,sub);b.append(av,txt);b.onclick=()=>openConversation(c.id);list.appendChild(b);
  }
}
async function openConversation(id){
  activeConversation=id;
  const c=conversations.find(x=>x.id===id);
  const peer=c?.conversation_members?.map(m=>m.profiles).find(p=>p?.id!==currentUser.id);
  const title=c?.is_group?(c.title||"گروه"):peer?.email||"گفت‌وگوی خصوصی";
  $("welcome").classList.add("hidden");$("activeChat").classList.remove("hidden");
  $("chatTitle").textContent=title;$("chatAvatar").textContent=title[0]?.toUpperCase()||"؟";
  await loadMessages();
  if(messageChannel)supabase.removeChannel(messageChannel);
  messageChannel=supabase.channel("messages-"+id).on("postgres_changes",{event:"INSERT",schema:"public",table:"messages",filter:`conversation_id=eq.${id}`},payload=>{
    if(payload.new.sender_id!==currentUser.id) appendMessage(payload.new);
  }).subscribe();
  await loadConversations();
}
async function loadMessages(){
  const {data,error}=await supabase.from("messages").select("*").eq("conversation_id",activeConversation).order("created_at",{ascending:true}).limit(200);
  if(error){toast(error.message);return;}
  $("messages").innerHTML="";(data||[]).forEach(appendMessage);scrollMessages();
}
function appendMessage(m){
  if(document.querySelector(`[data-message-id="${m.id}"]`))return;
  const div=document.createElement("div");div.className="msg"+(m.sender_id===currentUser.id?" mine":"");div.dataset.messageId=m.id;
  const body=document.createElement("div");body.textContent=m.body;
  const time=document.createElement("small");time.textContent=new Date(m.created_at).toLocaleTimeString("fa-IR",{hour:"2-digit",minute:"2-digit"});
  div.append(body,time);$("messages").appendChild(div);scrollMessages();
}
function scrollMessages(){$("messages").scrollTop=$("messages").scrollHeight;}
$("messageForm").addEventListener("submit",async e=>{
  e.preventDefault();const body=$("messageInput").value.trim();if(!body||!activeConversation)return;
  $("messageInput").value="";
  const {error}=await supabase.from("messages").insert({conversation_id:activeConversation,sender_id:currentUser.id,body});
  if(error){$("messageInput").value=body;toast(error.message);}
});
if(!configured){$("authMessage").textContent="برای راه‌اندازی آنلاین، فایل app.js را با اطلاعات Supabase تنظیم کن.";}
